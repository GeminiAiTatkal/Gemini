// Function to safely parse proxy string into an object
// It handles cases where user/pass might be missing.
function parseProxyString(str) {
    const parts = str.split(":");
    // Ensure all parts are defined, even if empty strings
    let ip = parts[0] ? parts[0].trim() : '';
    let port = parts[1] ? parts[1].trim() : '';
    let user = parts[2] ? parts[2].trim() : '';
    let pass = parts[3] ? parts[3].trim() : '';

    return { ip, port, user, pass };
}

// Function to format proxy object back to string for display in the UI
function formatProxyForDisplay(proxyObj) {
    let display = `${proxyObj.ip}:${proxyObj.port}`;
    if (proxyObj.user) {
        display += `:${proxyObj.user}`;
        // Mask password for display purposes, show '****' if it exists
        if (proxyObj.pass) {
            display += `:${'****'}`;
        }
    }
    return display;
}

// Sends the proxy details to the background script to apply using message passing
function applyProxy(proxy) {
    // Send a message to the background script
    chrome.runtime.sendMessage({
        action: "setProxy",
        ip: proxy.ip,
        port: proxy.port,
        username: proxy.user,
        password: proxy.pass
    });
    // No need for a callback here, background script will send a status message back
}

// Sends the clear proxy command to the background script using message passing
function clearProxy() {
    // Send a message to the background script
    chrome.runtime.sendMessage({ action: "clearProxy" });
    // No need for a callback here, background script will send a status message back
}

// Loads and displays saved proxies from local storage
function loadProxies() {
    chrome.storage.local.get("proxies", function(data) {
        const proxyList = document.getElementById("proxyList");
        proxyList.innerHTML = ""; // Clear existing list to prevent duplicates

        // Ensure data.proxies is an array, default to empty if not found
        const proxies = Array.isArray(data.proxies) ? data.proxies : [];

        if (proxies.length === 0) {
            const noProxiesMessage = document.createElement("p");
            noProxiesMessage.textContent = "No proxies saved yet.";
            noProxiesMessage.style.color = "#ccc";
            noProxiesMessage.style.textAlign = "center";
            noProxiesMessage.style.marginTop = "20px";
            proxyList.appendChild(noProxiesMessage);
            return; // Exit if no proxies
        }

        proxies.forEach((proxyObj, index) => { // Now iterating over objects
            const div = document.createElement("div");
            div.className = "proxy-entry";

            const span = document.createElement("span");
            span.textContent = formatProxyForDisplay(proxyObj); // Display formatted string
            span.title = `IP: ${proxyObj.ip}, Port: ${proxyObj.port}` + (proxyObj.user ? `, User: ${proxyObj.user}` : ''); // Tooltip

            const useBtn = document.createElement("button");
            useBtn.textContent = "Enable";
            useBtn.title = `Enable ${proxyObj.ip}:${proxyObj.port}`; // Add a tooltip
            useBtn.onclick = () => applyProxy(proxyObj); // Pass the object directly

            const delBtn = document.createElement("button");
            delBtn.textContent = "❌"; // Unicode cross symbol for delete
            delBtn.title = `Delete ${proxyObj.ip}:${proxyObj.port}`; // Add a tooltip
            delBtn.onclick = () => deleteProxy(index);

            div.appendChild(span);
            div.appendChild(useBtn);
            div.appendChild(delBtn);
            proxyList.appendChild(div);
        });
    });
}

// Saves the new proxy from the input field
function saveProxy() {
    const inputElement = document.getElementById("proxyInput");
    const inputString = inputElement.value.trim(); // Get input and trim whitespace

    // Basic validation: ensure it has at least IP and Port
    const parts = inputString.split(":");
    if (parts.length < 2 || !parts[0].trim() || !parts[1].trim()) { // Check if IP and Port are not empty after trim
        showMessage("Invalid format. Please enter at least ip:port (e.g., 192.168.1.1:8080)", "error");
        return;
    }

    const newProxyObj = parseProxyString(inputString); // Parse into object

    chrome.storage.local.get("proxies", function(data) {
        const proxies = Array.isArray(data.proxies) ? data.proxies : [];

        // Optional: Check for duplicates before saving
        const isDuplicate = proxies.some(p =>
            p.ip === newProxyObj.ip &&
            p.port === newProxyObj.port &&
            p.user === newProxyObj.user &&
            p.pass === newProxyObj.pass
        );

        if (isDuplicate) {
            showMessage("This proxy already exists in your list!", "warning"); // Use a warning type
            return;
        }

        proxies.push(newProxyObj); // Save the object
        chrome.storage.local.set({ proxies: proxies }, function() {
            if (chrome.runtime.lastError) {
                console.error("Error saving proxy:", chrome.runtime.lastError.message);
                showMessage("Error saving proxy: " + chrome.runtime.lastError.message, "error");
            } else {
                inputElement.value = ""; // Clear input after successful saving
                loadProxies(); // Reload the list to show the new entry
                showMessage("Proxy saved successfully!", "success");
            }
        });
    });
}

// Deletes a proxy from the list
function deleteProxy(index) {
    chrome.storage.local.get("proxies", function(data) {
        const proxies = Array.isArray(data.proxies) ? data.proxies : [];
        if (index >= 0 && index < proxies.length) {
            proxies.splice(index, 1); // Remove the proxy at the given index
            chrome.storage.local.set({ proxies: proxies }, function() {
                if (chrome.runtime.lastError) {
                    console.error("Error deleting proxy:", chrome.runtime.lastError.message);
                    showMessage("Error deleting proxy: " + chrome.runtime.lastError.message, "error");
                } else {
                    loadProxies(); // Reload the list after deletion
                    showMessage("Proxy deleted successfully!", "success");
                }
            });
        }
    });
}

// Function to display temporary status messages in the popup
function showMessage(message, type) {
    let statusMessageDiv = document.getElementById("statusMessage");
    if (!statusMessageDiv) {
        statusMessageDiv = document.createElement("div");
        statusMessageDiv.id = "statusMessage";
        // Create a dedicated message container if you prefer, e.g., in popup.html
        // For simplicity, appending to body.
        document.querySelector('body').appendChild(statusMessageDiv);
    }

    statusMessageDiv.textContent = message;
    // Define colors for different message types
    let bgColor, textColor;
    switch (type) {
        case "success":
            bgColor = "rgba(40, 167, 69, 0.2)"; // Green
            textColor = "#a8f0a8";
            break;
        case "error":
            bgColor = "rgba(220, 53, 69, 0.2)"; // Red
            textColor = "#ff8f8f";
            break;
        case "warning": // Added for duplicate proxy
            bgColor = "rgba(255, 193, 7, 0.2)"; // Yellow
            textColor = "#ffc107";
            break;
        default:
            bgColor = "rgba(100, 100, 100, 0.2)"; // Grey
            textColor = "#cccccc";
    }

    statusMessageDiv.style.color = textColor;
    statusMessageDiv.style.backgroundColor = bgColor;
    statusMessageDiv.style.marginTop = "10px";
    statusMessageDiv.style.padding = "5px";
    statusMessageDiv.style.borderRadius = "3px";
    statusMessageDiv.style.fontWeight = "bold";
    statusMessageDiv.style.fontSize = "0.9em";
    statusMessageDiv.style.textAlign = "center";
    statusMessageDiv.style.opacity = "1"; // Ensure it's visible
    statusMessageDiv.style.transition = "opacity 0.5s ease-in-out"; // Smooth fade out

    // Automatically hide the message after a few seconds
    setTimeout(() => {
        statusMessageDiv.style.opacity = "0"; // Start fade out
        // Remove element after fade out to clean up DOM
        setTimeout(() => {
            if (statusMessageDiv.parentNode) {
                statusMessageDiv.parentNode.removeChild(statusMessageDiv);
            }
        }, 500); // After the fade transition
    }, 3000); // Message visible for 3 seconds
}


// Add event listeners to buttons
document.getElementById("saveBtn").onclick = saveProxy;
document.getElementById("useHomeBtn").onclick = () => {
    clearProxy();
};

// Initial load of proxies when the popup is opened
loadProxies();