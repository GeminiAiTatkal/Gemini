// This defines your proxy configuration object
let currentProxyConfig = {
    mode: "fixed_servers", // Tells the browser we're using a specific proxy server
    rules: {
        singleProxy: {
            scheme: "http", // Default to HTTP. You could make this dynamic or consider SOCKS5.
            host: "",       // Placeholder for the proxy IP or hostname
            port: 0         // Placeholder for the proxy port
        },
        bypassList: ["localhost", "<local>"] // These websites will NOT use the proxy
    }
};

// A reference to the proxy authentication handler
let authListenerActive = false; // To track if the listener is currently active

// Function to handle proxy authentication
function handleAuthRequired(details, callbackFn) {
    // We only provide credentials if we have a username and password stored.
    // NOTE: For a more robust solution, especially in Manifest V3,
    // it's better to read these credentials from chrome.storage rather than global variables.
    if (typeof currentUsername !== 'undefined' && typeof currentPassword !== 'undefined' && currentUsername && currentPassword) {
        console.log("Providing proxy authentication credentials.");
        callbackFn({ authCredentials: { username: currentUsername, password: currentPassword } });
    } else {
        // If no credentials are available, the proxy authentication will likely fail.
        console.warn("Proxy authentication required but no credentials available. Request may fail.");
        callbackFn({ cancel: false }); // Allow the request to proceed without authentication (might fail).
    }
}

// Function to set the proxy
function setProxy(ip, port, username, password) {
    // Parse the port to a number and validate its range
    const parsedPort = parseInt(port, 10);
    if (isNaN(parsedPort) || parsedPort < 1 || parsedPort > 65535) { // Port numbers must be between 1 and 65535
        console.error("Invalid or out-of-range port provided:", port);
        chrome.runtime.sendMessage({ status: "error", message: "Invalid port number. Please use a number between 1 and 65535." });
        return;
    }

    // Update the proxy configuration
    currentProxyConfig.rules.singleProxy.host = ip;
    currentProxyConfig.rules.singleProxy.port = parsedPort;

    // Store the current username and password globally for the authentication listener to use.
    // This is a simple approach; using chrome.storage might be better for larger extensions.
    currentUsername = username;
    currentPassword = password;

    // Apply the proxy settings
    chrome.proxy.settings.set({ value: currentProxyConfig, scope: "regular" }, function() {
        if (chrome.runtime.lastError) {
            console.error("Proxy setting error: ", chrome.runtime.lastError.message);
            // Send an error message back to popup.js
            chrome.runtime.sendMessage({ status: "error", message: "Failed to set proxy: " + chrome.runtime.lastError.message });
        } else {
            console.log("Proxy set successfully to:", ip + ":" + port);
            // Send a success message back to popup.js
            chrome.runtime.sendMessage({ status: "success", message: "Proxy set successfully!" });

            // Add the listener only if it's not already active
            if (!authListenerActive) {
                chrome.webRequest.onAuthRequired.addListener(
                    handleAuthRequired, // Use our dedicated handler function
                    { urls: ["<all_urls>"] },
                    ['blocking', 'requestHeaders'] // Added 'requestHeaders'; can be useful for authentication
                );
                authListenerActive = true;
                console.log("Proxy authentication listener added.");
            } else {
                console.log("Proxy authentication listener already active.");
            }
        }
    });
}

// Function to clear the proxy
function clearProxy() {
    chrome.proxy.settings.clear({ scope: "regular" }, function() {
        if (chrome.runtime.lastError) {
            console.error("Proxy clearing error: ", chrome.runtime.lastError.message);
            // Send an error message back to popup.js
            chrome.runtime.sendMessage({ status: "error", message: "Failed to clear proxy: " + chrome.runtime.lastError.message });
        } else {
            console.log("Proxy cleared successfully!");
            // Send a success message back to popup.js
            chrome.runtime.sendMessage({ status: "success", message: "Proxy cleared successfully!" });

            // Remove the authentication listener when the proxy is cleared
            if (authListenerActive) {
                chrome.webRequest.onAuthRequired.removeListener(handleAuthRequired);
                authListenerActive = false;
                console.log("Proxy authentication listener removed.");
            }
            // Reset username and password
            currentUsername = undefined;
            currentPassword = undefined;
        }
    });
}

// This chrome.runtime.onMessage listener receives messages from popup.js.
// This is the primary way for popup.js and background.js to communicate.
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.action === "setProxy") {
        setProxy(request.ip, request.port, request.username, request.password);
        // Since setProxy/clearProxy are async operations, sendResponse() is not used here directly.
        // Instead, status messages are sent back to popup.js via chrome.runtime.sendMessage.
    } else if (request.action === "clearProxy") {
        clearProxy();
    }
});

// Load existing proxy status on startup (optional, but good practice)
// This ensures that if the extension reloads, it remembers its last known state.
chrome.proxy.settings.get({incognito: false}, function(config) {
    if (config && config.value && config.value.mode === "fixed_servers" && config.value.rules.singleProxy.host) {
        console.log("Extension started. Proxy is already set to:", config.value.rules.singleProxy.host + ":" + config.value.rules.singleProxy.port);

        // If a proxy is already set, re-add the authentication listener.
        // However, credentials would need to be loaded from chrome.storage to be truly persistent.
        // For this demo, we assume credentials won't be available until explicitly set.
        if (!authListenerActive) {
            chrome.webRequest.onAuthRequired.addListener(
                handleAuthRequired,
                { urls: ["<all_urls>"] },
                ['blocking', 'requestHeaders']
            );
            authListenerActive = true;
            console.log("Authentication listener re-added for existing proxy.");
        }
    } else {
        console.log("Extension started. No proxy currently set.");
    }
});